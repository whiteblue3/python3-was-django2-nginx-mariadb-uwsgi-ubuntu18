from django.http import HttpResponse
from django.shortcuts import render
from conf.common import db
import logging

from django.template import loader
from conf.common import s3
from botocore.exceptions import ClientError
import uuid

logger = logging.getLogger(__name__)

def index(request):
    html = ''
    try:
        connection = db.connect_db()
        with connection.cursor() as cursor:
            # Read a single record
            try:
                html = db.query_db(cursor, 'SELECT * FROM conf.genre')
            except Exception as e:
                html = '500 Internal Error'
                # html = 'Exception number: {}, value {}'.format(e.args[0], e.args[1])
    finally:
        db.close_db(connection)

    return HttpResponse(html)

def upload(request):
    template = loader.get_template('cms/upload.html')
    context = {
        'home': 'https://127.0.0.1:8080/cms/upload/',
    }
    return HttpResponse(template.render(context, request))

def upload_check(request):
    if request.method == 'POST':
        # User selected file information
        filename = request.FILES['file'].name
        filebody = request.FILES['file']
        s3prefix = "img"

        extension = str(filename).split('.')[-1]

        # make unique filename
        uid = str(uuid.uuid1())
        uniquename = uid.replace('-', '') + "." + extension

        remote_file_path = s3.upload_data_s3(filebody, s3prefix, uniquename)
        if remote_file_path is None:
            return HttpResponse("Upload Failed")
        else:
            return HttpResponse("Upload Success : " + remote_file_path)
