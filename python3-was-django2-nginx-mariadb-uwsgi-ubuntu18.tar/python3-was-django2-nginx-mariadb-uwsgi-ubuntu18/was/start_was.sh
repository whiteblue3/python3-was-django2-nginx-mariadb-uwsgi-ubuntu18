sudo killall uwsgi_python36
sudo -uubuntu uwsgi_python36 /etc/uwsgi/sites/was.ini --master --die-on-term &
