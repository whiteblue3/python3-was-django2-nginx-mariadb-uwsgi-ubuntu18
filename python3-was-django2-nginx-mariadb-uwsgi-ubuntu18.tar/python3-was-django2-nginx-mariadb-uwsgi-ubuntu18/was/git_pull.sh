sudo git fetch origin master
sudo git reset --hard origin/master
sudo chown ubuntu.ubuntu *
sudo chmod +x git_pull.sh
sudo chmod +x start_was.sh