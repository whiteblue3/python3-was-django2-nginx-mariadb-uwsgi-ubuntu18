from django.apps import AppConfig


class ListenConfig(AppConfig):
    name = 'listen'
