import boto3
from botocore.exceptions import ClientError
import logging
from django.conf import settings

logger = logging.getLogger(__name__)
s3 = boto3.client('s3')
bucket = settings.AWS_STORAGE_BUCKET_NAME
location = settings.AWS_PUBLIC_MEDIA_LOCATION

# Boto3 API

def upload_file_s3(absolute_file_path, remote_path, remote_file_name):
    remote_file_path = '%s/%s/%s' % (location, remote_path, remote_file_name)
    try:
        s3.upload_file(absolute_file_path, bucket, remote_file_path)
    except ClientError as e:
        logger.exception("Upload file to S3 Error {}".format(e))
        raise e
        return None
    else:
        return remote_file_path

def upload_data_s3(data, remote_path, remote_file_name):
    remote_file_path = '%s/%s/%s' % (location, remote_path, remote_file_name)
    try:
        s3.upload_fileobj(data, bucket, remote_file_path)
    except ClientError as e:
        logger.exception("Upload file data to S3 Error {}".format(e))
        raise e
        return None
    else:
        return remote_file_path

def delete_file_s3(path, file_name):
    try:
        s3.delete_object(Bucket=bucket, Key='%s/%s/%s' % (location, path, file_name))
    except ClientError as e:
        logger.exception("Delete file from S3 Error {}".format(e))
        raise e

def read_file_s3(path, file_name):
    try:
        result = s3.get_object(Bucket=bucket, Key='%s/%s/%s' % (location, path, file_name))
    except ClientError as e:
        logger.exception("Read file from S3 Error {}".format(e))
        raise e
        return None
    else:
        return result['Body'].read()
