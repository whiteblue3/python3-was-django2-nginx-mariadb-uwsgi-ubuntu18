import pymysql.cursors
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

def connect_db():
    host = settings.DATABASES["default"]["HOST"]
    user = settings.DATABASES["default"]["USER"]
    passwd = settings.DATABASES["default"]["PASSWORD"]
    dbname = settings.DATABASES["default"]["NAME"]
    dbport = settings.DATABASES["default"]["PORT"]
    charset = 'utf8'
    cursorclass = pymysql.cursors.DictCursor

    try:
        connection = pymysql.connect(host=host, user=user, password=passwd, db=dbname, port=dbport, charset=charset, cursorclass=cursorclass)
    except Exception as e:
        logger.exception("Database Connection Error {}".format(e))
        raise
    else:
        # result = ''
        # try:
        #     with connection.cursor() as cursor:
        #         # Read a single record
        #         sql = "SELECT * FROM conf.genre"
        #         cursor.execute(sql)
        #         result = cursor.fetchall()
        # finally:
        #     connection.close()
        return connection

def query_db(cursor, sql):
    try:
        cursor.execute(sql)
    except Exception as e:
        logger.exception("Database Query Error {}".format(e))
        raise
    else:
        return cursor.fetchall()

def close_db(connection):
    try:
        connection.close()
    except Exception as e:
        logger.exception("Database Close Error {}".format(e))
        raise

