from .base import *

config_secret_prod = json.loads(open(CONFIG_SECRET_PROD_FILE).read())

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False
TEMPLATE_DEBUG = False

ALLOWED_HOSTS = config_secret_prod['django']['allowed_hosts']

# Database
# https://docs.djangoproject.com/en/2.1/ref/settings/#databases
# PyMySQL : https://github.com/PyMySQL/PyMySQL/

DATABASES = {
    'default': {
        'ENGINE': config_secret_prod['django']['DATABASES']['ENGINE'],
        'NAME': config_secret_prod['django']['DATABASES']['NAME'],
        'USER': config_secret_prod['django']['DATABASES']['USER'],
        'PASSWORD': config_secret_prod['django']['DATABASES']['PASSWORD'],
        'HOST': config_secret_prod['django']['DATABASES']['HOST'],
        'PORT': config_secret_prod['django']['DATABASES']['PORT'],
    }
}

# Disable Django's logging setup
LOGGING_CONFIG = None

LOGLEVEL = os.environ.get('LOGLEVEL', 'info').upper()

logging.config.dictConfig({
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'default': {
            # exact format is not important, this is the minimum information
            'format': '%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
        },
        'verbose': {
            'format' : "[%(asctime)s] %(levelname)s [%(name)s:%(lineno)s] %(message)s",
            'datefmt' : "%d/%b/%Y %H:%M:%S"
        },
        'django.server': DEFAULT_LOGGING['formatters']['django.server'],
    },
    'handlers': {
        'file': {
            'level': 'INFO',
            'class':'logging.handlers.TimedRotatingFileHandler',
            'filename': os.path.join('/srv/logs/django', 'log'),
            'when': 'D', # this specifies the interval
            'interval': 1, # defaults to 1, only necessary for other values
            'backupCount': 7, # how many backup file to keep, 7 days
            'formatter': 'default',
        },
        'django.server': DEFAULT_LOGGING['handlers']['django.server'],
    },
    'loggers': {
        # default for all undefined Python modules
        'django': {
            'handlers': ['file'],
            'level': os.getenv('DJANGO_LOG_LEVEL', 'INFO'),
        },
        '': {
            'level': os.getenv('DJANGO_LOG_LEVEL', 'INFO'),
            'handlers': ['file'],
        },
        # Our application code
        'app': {
            'level': os.getenv('DJANGO_LOG_LEVEL', 'INFO'),
            # Avoid double logging because of root logger
            'propagate': False,
        },
        # Prevent noisy modules from logging to Sentry
        'noisy_module': {
            'level': 'ERROR',
            'handlers': ['file'],
            'propagate': False,
        },
        # Default runserver request logging
        'django.server': DEFAULT_LOGGING['loggers']['django.server'],
    },
})

AWS_STORAGE_BUCKET_NAME = config_secret_prod['django']['AWS_STORAGE_BUCKET_NAME']

AWS_S3_CUSTOM_DOMAIN = '%s.s3.amazonaws.com' % AWS_STORAGE_BUCKET_NAME

AWS_S3_OBJECT_PARAMETERS = {
    'CacheControl': 'max-age=86400',
}

AWS_LOCATION = 'static'
STATICFILES_STORAGE = 'storages.backends.s3boto3.S3Boto3Storage'
STATIC_URL = "https://%s/%s/" % (AWS_S3_CUSTOM_DOMAIN, AWS_LOCATION)
AWS_DEFAULT_ACL = "public-read"
AWS_S3_ENCRYPTION = True
DEFAULT_FILE_STORAGE = 'conf.storage_backends.MediaStorage'
AWS_PUBLIC_MEDIA_LOCATION = 'media'