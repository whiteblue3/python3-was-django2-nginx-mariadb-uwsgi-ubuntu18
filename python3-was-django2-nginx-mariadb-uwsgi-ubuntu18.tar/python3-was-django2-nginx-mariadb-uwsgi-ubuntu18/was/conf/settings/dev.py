from .base import *

config_secret_dev = json.loads(open(CONFIG_SECRET_DEV_FILE).read())

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False
TEMPLATE_DEBUG = False

ALLOWED_HOSTS = config_secret_dev['django']['allowed_hosts']

INSTALLED_APPS = ['sslserver',] + INSTALLED_APPS

# Database
# https://docs.djangoproject.com/en/2.1/ref/settings/#databases
# PyMySQL : https://github.com/PyMySQL/PyMySQL/

DATABASES = {
    'default': {
        'ENGINE': config_secret_dev['django']['DATABASES']['ENGINE'],
        'NAME': config_secret_dev['django']['DATABASES']['NAME'],
        'USER': config_secret_dev['django']['DATABASES']['USER'],
        'PASSWORD': config_secret_dev['django']['DATABASES']['PASSWORD'],
        'HOST': config_secret_dev['django']['DATABASES']['HOST'],
        'PORT': config_secret_dev['django']['DATABASES']['PORT'],
    },
}

# Disable Django's logging setup
LOGGING_CONFIG = None

LOGLEVEL = os.environ.get('LOGLEVEL', 'info').upper()

logging.config.dictConfig({
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'default': {
            # exact format is not important, this is the minimum information
            'format': '%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
        },
        'django.server': DEFAULT_LOGGING['formatters']['django.server'],
    },
    'handlers': {
        # console logs to stderr
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'default',
        },
        'django.server': DEFAULT_LOGGING['handlers']['django.server'],
    },
    'loggers': {
        # default for all undefined Python modules
        '': {
            'level': 'WARNING',
            'handlers': ['console'],
        },
        # Our application code
        'app': {
            'level': LOGLEVEL,
            'handlers': ['console'],
            # Avoid double logging because of root logger
            'propagate': False,
        },
        # Prevent noisy modules from logging to Sentry
        'noisy_module': {
            'level': 'ERROR',
            'handlers': ['console'],
            'propagate': False,
        },
        # Default runserver request logging
        'django.server': DEFAULT_LOGGING['loggers']['django.server'],
    },
})

AWS_STORAGE_BUCKET_NAME = config_secret_dev['django']['AWS_STORAGE_BUCKET_NAME']

AWS_S3_CUSTOM_DOMAIN = '%s.s3.amazonaws.com' % AWS_STORAGE_BUCKET_NAME

AWS_S3_OBJECT_PARAMETERS = {
    'CacheControl': 'max-age=86400',
}

AWS_LOCATION = 'static'
STATICFILES_STORAGE = 'storages.backends.s3boto3.S3Boto3Storage'
STATIC_URL = "https://%s/%s/" % (AWS_S3_CUSTOM_DOMAIN, AWS_LOCATION)
AWS_DEFAULT_ACL = "public-read"
AWS_S3_ENCRYPTION = True
DEFAULT_FILE_STORAGE = 'conf.storage_backends.MediaStorage'
AWS_PUBLIC_MEDIA_LOCATION = 'media'